//
//  Profile.swift
//  AlcoholMeter
//
//  Created by Natalia De Biasio on 04/11/2021.
//


import SwiftUI

//@main
//struct SwiftUI_dataflow_demoApp: App{
//    var body: some Scene{
//        WindowGroup{
//            PerfilViewController()
//                .environmentObject(Profile())
//        }
//    }
//}
//class GlobalEnviroment: ObservableObject{
//    @Published var nombre = ""
//    @Published var edad = 0
//    @Published var fechaDeNac = ""
//    @Published var sexo = ""
//    @Published var peso = 0
//    @Published var altura = 0
//    @Published var limite = 0
//}
