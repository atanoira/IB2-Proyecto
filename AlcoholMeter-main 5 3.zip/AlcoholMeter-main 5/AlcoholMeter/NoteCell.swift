//
//  NoteCell.swift
//  AlcoholMeter
//
//  Created by Natalia De Biasio on 16/11/2021.
//

import UIKit

class NoteCell: UITableViewCell{
    
    
    
}
