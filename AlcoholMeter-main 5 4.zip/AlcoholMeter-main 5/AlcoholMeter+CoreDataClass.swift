//
//  AlcoholMeter+CoreDataClass.swift
//  AlcoholMeter
//
//  Created by Natalia De Biasio on 17/11/2021.
//
//

import Foundation
import CoreData


public class AlcoholMeter: NSManagedObject {

}
